import java.util.*;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

public class BruteCollinearPoints {
    private LineSegment[] lines = new LineSegment[2];
    private int num;
    private Point[] points = new Point[2];
    private Point[] resize(int size)
    {
        Point[] newPoints = new Point[size];
        return newPoints;
    }
    private LineSegment[] resizeLines(int size)
    {
        LineSegment[] newLines = new LineSegment[size];
        for (int i = 0; i < num; i++)
        {
            newLines[i] = lines[i];
        }
        return newLines;
    }
    public BruteCollinearPoints(Point[] points)    // finds all line segments containing 4 points
    {
        if (points == null) throw new NullPointerException("");
        this.points = resize(points.length);
        for (int i = 0; i < this.points.length; i++)
        {
            if (points[i] == null) throw new NullPointerException("");
            for (int j = 0; j < i; j++)
            {
                if (points[j].equals(points[i]))
                {
                    throw new java.lang.IllegalArgumentException("");
                }
            }
            if (points[i] == null) throw new NullPointerException("");
            this.points[i] = points[i];
        }
        num = 0;
    }
    public           int numberOfSegments()        // the number of line segments
    {
        return num;
    }
    public LineSegment[] segments()                // the line segments
    {
        Arrays.sort(points);      
        for (int i = 0; i < points.length; i++)
        {
            for (int j = i + 1; j < points.length; j++)
            {
                for (int m = j + 1; m < points.length; m++)
                {
                    for (int n = m + 1; n < points.length; n++)
                    {
                        if (points[i].slopeTo(points[j]) == points[j].slopeTo(points[m]) 
                                && points[j].slopeTo(points[m]) == points[m].slopeTo(points[n]))
                        {
                            if (num == lines.length)
                            {
                                lines = resizeLines(2 * lines.length);
                            }
                            lines[num] = new LineSegment(points[i], points[n]);
                            num++;
                        }
                    }
                }
            } 
        }
        LineSegment[] retLines = new LineSegment[num];
        for (int i = 0; i < num; i++)
        {
            retLines[i] = lines[i];
        }
        return retLines;
    }
    public static void main(String[] args)
    {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }
        
        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();
        
        // print and draw the line segments
        BruteCollinearPoints collinear = new BruteCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
