import java.util.*;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

public class FastCollinearPoints{
    private LineSegment[] lines = new LineSegment[2];
    private int num;
    private Point[] points = new Point[2];
    private Point[] resize(int size)
    {
        Point[] newPoints = new Point[size];
        return newPoints;
    }
    private LineSegment[] resizeLines(int size)
    {
        LineSegment[] newLines = new LineSegment[size];
        for (int i = 0; i < num; i++)
        {
            newLines[i] = lines[i];
        }
        return newLines;
    }
    public FastCollinearPoints(Point[] points)     // finds all line segments containing 4 or more points
    {
        if (points == null) throw new NullPointerException("");
        this.points = resize(points.length);
        for (int i = 0; i < this.points.length; i++)
        {
            if (points[i] == null) throw new NullPointerException("");
            for (int j = 0; j < i; j++)
            {
                if (points[j].equals(points[i]))
                {
                    throw new java.lang.IllegalArgumentException("");
                }
            }
            this.points[i] = points[i];
        }
        num = 0;
    }
    public           int numberOfSegments()        // the number of line segments
    {
        return num;
    }
    public LineSegment[] segments()                // the line segments
    {
        Point[] ops = new Point[points.length];
        for (int i = 0; i < points.length; i++)
        {
            ops[i] = points[i];
        }
        for (int i = 0; i < ops.length; i++)
        {
            Arrays.sort(ops, ops[i].slopeOrder());
            int counter = 0;
            int endIndex = 0;
            for (int m = 2; m < ops.length; m++)
            {
                //Find first group of collinear, sort them and assign them to 
                if (ops[0].slopeTo(ops[m]) == ops[0].slopeTo(ops[m - 1]))
                {
                    endIndex = m;
                    counter++;
                }
                if (ops[0].slopeTo(ops[m]) != ops[0].slopeTo(ops[m - 1]) || m == ops.length - 1)
                {
                    if (counter >= 2)
                    {
                        Point[] aux = new Point[counter + 2];
                        aux[0] = ops[0];
                        for (int x = 1; x < counter + 2; x++)
                        {
                            aux[x] = ops[x -1 + endIndex - counter];
                        }
                        Arrays.sort(aux); //could print all members for debugging
                        LineSegment tempLine = new LineSegment(aux[0], aux[counter + 1]);
                        if (num == 0)
                        {
                            lines[num] = tempLine;
                            num++;   
                        }
                        else
                        {
                            boolean isNew = true;
                            for (int w = 0; w < num; w++)
                            {
                                if (lines[w].toString().equals(tempLine.toString()))
                                {
                                    isNew = false;
                                }
                            }
                            if (isNew)
                            {
                                if (num == lines.length)
                                {
                                    lines = resizeLines(2 * lines.length);
                                }
                                lines[num++] = tempLine;
                            }
                        }
                    }
                    counter = 0; //reset counter and look for new possible lines
                }
            } 
            for (int j = 0; j < ops.length; j++)
            {
                ops[j] = points[j];
            }
        }
        LineSegment[] retLines = new LineSegment[num];
        for (int i = 0; i < num; i++)
        {
            retLines[i] = lines[i];
        }
        return retLines;
    }    
    public static void main(String[] args)
    {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }
        
        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();
        
        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
